<?php
namespace D\model\modules\SystemPackages\ModulePackageMock;

use D\model\classes\ModuleController;

class Controller extends ModuleController{
  public function test(){}
}
